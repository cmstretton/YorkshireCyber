
<?php
namespace Plugins\FaveoAI\Services;

use Illuminate\Support\Facades\Http;

class ChatGPTService {
    protected $apiKey;
    protected $model;

    public function __construct() {
        $this->apiKey = config('faveo_ai.openai_api_key');
        $this->model  = config('faveo_ai.model');
    }

    public function chat($messages, $temp = 0.3) {
        $res = Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey
        ])->post('https://api.openai.com/v1/chat/completions', [
            'model' => $this->model,
            'messages' => $messages,
            'temperature' => $temp
        ])->json();

        return $res['choices'][0]['message']['content'] ?? null;
    }
}
