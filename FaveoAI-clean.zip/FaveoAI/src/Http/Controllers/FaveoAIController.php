
<?php
namespace Plugins\FaveoAI\Http\Controllers;

use App\Http\Controllers\Controller;
use Plugins\FaveoAI\Services\ChatGPTService;
use App\Model\helpdesk\Ticket;
use App\Model\helpdesk\Ticket\Ticket_Thread;

class FaveoAIController extends Controller {

    protected $ai;

    public function __construct(ChatGPTService $ai) {
        $this->middleware('auth');
        $this->ai = $ai;
    }

    public function autoReply($ticketId) {
        $ticket = Ticket::findOrFail($ticketId);

        $reply = $this->ai->chat([
            ['role'=>'system','content'=>'You are a skilled IT support agent.'],
            ['role'=>'user','content'=>"Subject: {$ticket->title}
Message: {$ticket->body}"]
        ]);

        $thread = new Ticket_Thread();
        $thread->ticket_id = $ticket->id;
        $thread->is_internal = 0;
        $thread->thread_type = 'reply';
        $thread->user_id = auth()->id();
        $thread->poster = 'agent';
        $thread->body = $reply;
        $thread->save();

        return response()->json(['status'=>'success','reply'=>$reply]);
    }
}
