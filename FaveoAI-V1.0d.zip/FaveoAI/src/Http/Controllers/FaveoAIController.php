<?php
namespace Plugins\FaveoAI\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Plugins\FaveoAI\Services\ChatGPTService;
use App\Model\helpdesk\Ticket;
use App\Model\helpdesk\Ticket\Ticket_Thread;

class FaveoAIController extends Controller {

    protected ChatGPTService $ai;

    public function __construct(ChatGPTService $ai){
        $this->middleware('auth');
        $this->ai = $ai;
    }

    public function autoReply($ticketId){
        $ticket = Ticket::findOrFail($ticketId);

        $reply = $this->ai->chat([
            ['role'=>'system','content'=>'You are a professional IT support agent.'],
            ['role'=>'user','content'=>"Subject: {$ticket->title}
Message: {$ticket->body}"]
        ]);

        $t = new Ticket_Thread();
        $t->ticket_id = $ticket->id;
        $t->is_internal=0;
        $t->thread_type='reply';
        $t->user_id=auth()->id();
        $t->poster='agent';
        $t->body=$reply;
        $t->save();

        return response()->json(['status'=>'success','reply'=>$reply]);
    }
}
