<?php
namespace Plugins\FaveoAI\Services;

use Illuminate\Support\Facades\Http;

class ChatGPTService {
    protected string $apiKey;
    protected string $model;

    public function __construct() {
        $this->apiKey = config('faveo_ai.openai_api_key');
        $this->model  = config('faveo_ai.model');
    }

    public function chat(array $messages, float $temp=0.3) {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer '.$this->apiKey
        ])->post('https://api.openai.com/v1/chat/completions', [
            'model'=>$this->model,
            'messages'=>$messages,
            'temperature'=>$temp
        ]);

        $data = $response->json();
        return $data['choices'][0]['message']['content'] ?? null;
    }
}
