<?php
namespace Plugins\FaveoAI;

use Illuminate\Support\ServiceProvider;

class FaveoAIServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->mergeConfigFrom(__DIR__.'/../config/faveo_ai.php', 'faveo_ai');
    }

    public function boot()
    {
        $this->loadRoutesFrom(__DIR__ . '/../routes/faveo_ai.php');
        $this->loadViewsFrom(__DIR__ . '/../resources/views', 'FaveoAI');

        $this->publishes([
            __DIR__ . '/../config/faveo_ai.php' => config_path('faveo_ai.php'),
        ], 'config');
    }
}
