<?php
return [
    'openai_api_key' => env('OPENAI_API_KEY', ''),
    'model' => env('FAVEO_AI_MODEL', 'gpt-4.1-mini'),
];
