<?php
use Illuminate\Support\Facades\Route;
use Plugins\FaveoAI\Http\Controllers\FaveoAIController;

Route::group(['middleware'=>['web','auth']], function(){
    Route::post('/ai/ticket-reply/{ticketId}', [FaveoAIController::class,'autoReply']);
});
