<button id="aiAutoReply" class="btn btn-info btn-xs">AI Auto Reply</button>

<script>
document.getElementById('aiAutoReply').onclick = function() {
    fetch('/ai/ticket-reply/{{ $ticket->id }}', {
        method:'POST',
        headers:{"X-CSRF-TOKEN":"{{ csrf_token() }}"}
    })
    .then(r=>r.json())
    .then(d=>{
        alert('AI reply added');
        location.reload();
    });
};
</script>
